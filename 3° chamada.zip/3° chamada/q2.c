// 2. (2 pontos) Dada uma matriz 10×10 de inteiros faça um programa em C que imprima
// a diagonal principal e a diagonal secundária

int main(){
    int matriz[10][10];

    for (int i = 0; i < 10; i++){
        for (int j = 0; j < 10; j++)
        {
            scanf("%d", &matriz[i][j]);
        }
    }

 for (int i = 0; i < 10; i++){
        for (int j = 0; j < 10; j++)
        {
            if (i == j)
            {
                printf("Matriz Diagonal Principal");
            }
            
        }
    printf("\n");

    }

    for (int i = 0; i < 10; i++) {
        for (int j = 0; j < 10; i++)
        {
            printf("%d", matriz[i][j]);
        } 
   printf("\n");

    }    


    return 0;
}

